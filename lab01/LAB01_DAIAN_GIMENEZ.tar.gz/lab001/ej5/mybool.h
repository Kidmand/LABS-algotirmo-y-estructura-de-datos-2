#ifndef MY_BOOL

#define MY_BOOL

#define true 1
#define false 0

typedef int mybool;

#endif
